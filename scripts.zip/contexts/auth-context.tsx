"use client"

import React, { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { User } from "@/types/auth"
import { authService } from "@/services/auth-service"

interface AuthContextType {
    user: User | null
    isAuthenticated: boolean
    isLoading: boolean
    login: (email: string) => Promise<void>
    register: (name: string, email: string) => Promise<void>
    logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    login: async () => { },
    register: async () => { },
    logout: async () => { },
})

export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null)
    const [isLoading, setIsLoading] = useState(true)
    const router = useRouter()

    useEffect(() => {
        async function initAuth() {
            try {
                const currentUser = await authService.getCurrentUser()
                setUser(currentUser)
            } catch (error) {
                console.error("Failed to fetch user", error)
            } finally {
                setIsLoading(false)
            }
        }
        initAuth()
    }, [])

    const login = async (email: string) => {
        setIsLoading(true)
        try {
            const user = await authService.login(email)
            setUser(user)
            router.push("/dashboard")
        } finally {
            setIsLoading(false)
        }
    }

    const register = async (name: string, email: string) => {
        setIsLoading(true)
        try {
            const user = await authService.register(name, email)
            setUser(user)
            router.push("/dashboard")
        } finally {
            setIsLoading(false)
        }
    }

    const logout = async () => {
        setIsLoading(true)
        try {
            await authService.logout()
            setUser(null)
            router.push("/")
        } finally {
            setIsLoading(false)
        }
    }

    return (
        <AuthContext.Provider
            value={{
                user,
                isAuthenticated: !!user,
                isLoading,
                login,
                register,
                logout,
            }}
        >
            {children}
        </AuthContext.Provider>
    )
}

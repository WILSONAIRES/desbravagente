import { GeneratedContent } from "@/services/ai-service"
import { Unit, Member } from "@/types/clube"

const STORAGE_KEY = "dbv_generated_content"
const UNITS_KEY = "dbv_units"
const MEMBERS_KEY = "dbv_members"
const CLUB_INFO_KEY = "dbv_club_info"

export interface SavedContent extends GeneratedContent {
    title: string
    type: 'class' | 'specialty'
    requirementId: string
}

export const storageService = {
    // Content Storage
    saveContent(content: SavedContent): void {
        const current = this.getAllContent()
        // Overwrite if same requirement and same title (to distinguish between class/specialty)
        const updated = [content, ...current.filter(c => c.requirementId !== content.requirementId || c.title !== content.title)]
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
    },

    getContentByRequirement(requirementId: string, title?: string): SavedContent | undefined {
        const all = this.getAllContent()
        return all.find(c => c.requirementId === requirementId && (!title || c.title === title))
    },

    getAllContent(): SavedContent[] {
        if (typeof window === "undefined") return []
        const stored = localStorage.getItem(STORAGE_KEY)
        if (!stored) return []
        try {
            return JSON.parse(stored)
        } catch {
            return []
        }
    },

    getContentById(id: string): SavedContent | undefined {
        const all = this.getAllContent()
        return all.find((c) => c.id === id)
    },

    deleteContent(id: string): void {
        const current = this.getAllContent()
        const updated = current.filter((c) => c.id !== id)
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated))
    },

    // Units Management
    saveUnit(unit: Unit): void {
        const current = this.getUnits()
        const updated = [...current.filter(u => u.id !== unit.id), unit]
        localStorage.setItem(UNITS_KEY, JSON.stringify(updated))
    },

    getUnits(): Unit[] {
        if (typeof window === "undefined") return []
        const stored = localStorage.getItem(UNITS_KEY)
        return stored ? JSON.parse(stored) : []
    },

    getUnitById(id: string): Unit | undefined {
        return this.getUnits().find(u => u.id === id)
    },

    deleteUnit(id: string): void {
        const updated = this.getUnits().filter(u => u.id !== id)
        localStorage.setItem(UNITS_KEY, JSON.stringify(updated))
    },

    // Member Management
    saveMember(member: Member): void {
        const current = this.getMembers()
        const updated = [...current.filter(m => m.id !== member.id), member]
        localStorage.setItem(MEMBERS_KEY, JSON.stringify(updated))
    },

    getMembers(unitId?: string): Member[] {
        if (typeof window === "undefined") return []
        const stored = localStorage.getItem(MEMBERS_KEY)
        const all: Member[] = stored ? JSON.parse(stored) : []
        return unitId ? all.filter(m => m.unitId === unitId) : all
    },

    getMemberById(id: string): Member | undefined {
        return this.getMembers().find(m => m.id === id)
    },

    deleteMember(id: string): void {
        const updated = this.getMembers().filter(m => m.id !== id)
        localStorage.setItem(MEMBERS_KEY, JSON.stringify(updated))
    },

    // Club Info
    getClubName(): string {
        if (typeof window === "undefined") return "Meu Clube"
        const stored = localStorage.getItem(CLUB_INFO_KEY)
        return stored ? JSON.parse(stored).name : "Meu Clube"
    },

    saveClubName(name: string): void {
        localStorage.setItem(CLUB_INFO_KEY, JSON.stringify({ name }))
    }
}

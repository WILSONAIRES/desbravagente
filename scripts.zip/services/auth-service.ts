import { User } from "@/types/auth"

const MOCK_USER: User = {
    id: "1",
    name: "Diretor Exemplar",
    email: "diretor@desbravadores.com",
    role: "director",
    avatar: "/avatars/01.png",
}

export const authService = {
    async login(email: string): Promise<User> {
        // Simulate API call
        return new Promise((resolve) => {
            setTimeout(() => {
                const role = email.startsWith('admin') ? 'admin' : 'director'
                const user: User = { ...MOCK_USER, email, role }
                localStorage.setItem("dbv_user", JSON.stringify(user))
                resolve(user)
            }, 1000)
        })
    },

    async register(name: string, email: string): Promise<User> {
        return new Promise((resolve) => {
            setTimeout(() => {
                const role = email.startsWith('admin') ? 'admin' : 'director'
                const user: User = { ...MOCK_USER, name, email, role }
                localStorage.setItem("dbv_user", JSON.stringify(user))
                resolve(user)
            }, 1000)
        })
    },

    async logout(): Promise<void> {
        return new Promise((resolve) => {
            setTimeout(() => {
                localStorage.removeItem("dbv_user")
                resolve()
            }, 500)
        })
    },

    async getCurrentUser(): Promise<User | null> {
        return new Promise((resolve) => {
            const stored = localStorage.getItem("dbv_user")
            if (stored) {
                resolve(JSON.parse(stored))
            } else {
                resolve(null)
            }
        })
    },
}

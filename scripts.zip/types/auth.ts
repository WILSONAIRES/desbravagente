export interface User {
    id: string
    name: string
    email: string
    avatar?: string
    role: 'admin' | 'director' | 'counselor' | 'instructor'
}

export interface AuthState {
    user: User | null
    isAuthenticated: boolean
    isLoading: boolean
}

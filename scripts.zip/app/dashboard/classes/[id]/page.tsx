"use client"

import React from "react"
import { notFound } from "next/navigation"
import { classes } from "@/data/classes"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronLeft } from "lucide-react"
import Link from "next/link"
import { RequirementsList } from "@/components/classes/requirements-list"
import { GenerationModal } from "@/components/generation/generation-modal"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ActivityStudentManager } from "@/components/club/activity-student-manager"

// Correção para o erro de tipos do Next.js 15+
// Em vez de usar params diretamente, vamos usar React.use()
// Mas para compatibilidade com versões anteriores e simplicidade neste setup:
// Next.js 15+ compatibility: params is a Promise
export default function ClassDetailsPage({ params }: { params: Promise<{ id: string }> }) {
    const { id: classId } = React.use(params)
    const currentClass = classes.find((c) => c.id === classId)

    if (!currentClass) {
        notFound()
    }

    const handleGenerateContent = (id: string, description: string) => {
        setSelectedReq({ id, description })
        setModalOpen(true)
    }

    const [modalOpen, setModalOpen] = React.useState(false)
    const [selectedReq, setSelectedReq] = React.useState<{ id: string, description: string } | null>(null)
    const [activeTab, setActiveTab] = React.useState("requirements")

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4">
                <Link href="/dashboard/classes">
                    <Button variant="ghost" size="icon">
                        <ChevronLeft className="h-4 w-4" />
                    </Button>
                </Link>
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                        {currentClass.name}
                        <Badge variant={currentClass.type === 'regular' ? "default" : "secondary"}>
                            {currentClass.type === 'regular' ? 'Regular' : 'Avançada'}
                        </Badge>
                    </h1>
                </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full max-w-sm grid-cols-2">
                    <TabsTrigger value="requirements">Requisitos</TabsTrigger>
                    <TabsTrigger value="management">Gestão de Alunos</TabsTrigger>
                </TabsList>

                <TabsContent value="requirements" className="mt-6">
                    <RequirementsList
                        sections={currentClass.sections}
                        onGenerateClick={handleGenerateContent}
                    />
                </TabsContent>

                <TabsContent value="management" className="mt-6">
                    <ActivityStudentManager
                        activityId={currentClass.id}
                        activityName={currentClass.name}
                        type="class"
                        requirements={currentClass.sections}
                    />
                </TabsContent>
            </Tabs>

            {selectedReq && (
                <GenerationModal
                    open={modalOpen}
                    onOpenChange={setModalOpen}
                    requirementId={selectedReq.id}
                    requirementDescription={selectedReq.description}
                    className={currentClass.name}
                />
            )}
        </div>
    )
}

"use client"

import { useState, useEffect, use } from "react"
import Link from "next/link"
import { storageService } from "@/services/storage-service"
import { Member, Unit } from "@/types/clube"
import { specialties, getSpecialtyImage } from "@/data/specialties"
import { classes } from "@/data/classes"
import { Button } from "@/components/ui/button"
import { Plus, Users, ArrowLeft, ArrowRight, MoreHorizontal, User as UserIcon, Calendar, CheckCircle2, Search } from "lucide-react"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"

export default function UnitDetailsPage({ params }: { params: Promise<{ id: string }> }) {
    const resolvedParams = use(params)
    const unitId = resolvedParams.id

    const [unit, setUnit] = useState<Unit | null>(null)
    const [members, setMembers] = useState<Member[]>([])
    const [open, setOpen] = useState(false)
    const [newMemberName, setNewMemberName] = useState("")
    const [newMemberBirth, setNewMemberBirth] = useState("")

    useEffect(() => {
        loadData()
    }, [unitId])

    const loadData = () => {
        setUnit(storageService.getUnitById(unitId) || null)
        setMembers(storageService.getMembers(unitId))
    }

    const handleAddMember = () => {
        if (!newMemberName.trim() || !newMemberBirth) return

        const newMember: Member = {
            id: crypto.randomUUID(),
            name: newMemberName,
            dateOfBirth: newMemberBirth,
            unitId: unitId,
            progress: []
        }

        storageService.saveMember(newMember)
        setNewMemberName("")
        setNewMemberBirth("")
        setOpen(false)
        loadData()
    }

    if (!unit) return <div className="p-8 text-center">Unidade não encontrada.</div>

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4">
                <Link href="/dashboard/club">
                    <Button variant="ghost" size="icon">
                        <ArrowLeft className="h-4 w-4" />
                    </Button>
                </Link>
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-primary">{unit.name}</h1>
                    <p className="text-muted-foreground">Gerencie os membros desta unidade.</p>
                </div>
            </div>

            <div className="flex justify-between items-center gap-4">
                <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Buscar desbravador..." className="pl-8" />
                </div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild>
                        <Button>
                            <Plus className="mr-2 h-4 w-4" />
                            Cadastrar Desbravador
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Novo Desbravador</DialogTitle>
                            <DialogDescription>
                                Cadastre um novo membro na unidade {unit.name}. Apenas Nome e Data de Nascimento são necessários (LGPD).
                            </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                                <Label htmlFor="name">Nome Completo</Label>
                                <Input
                                    id="name"
                                    placeholder="Nome do desbravador"
                                    value={newMemberName}
                                    onChange={(e) => setNewMemberName(e.target.value)}
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="birth">Data de Nascimento</Label>
                                <Input
                                    id="birth"
                                    type="date"
                                    value={newMemberBirth}
                                    onChange={(e) => setNewMemberBirth(e.target.value)}
                                />
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
                            <Button onClick={handleAddMember}>Salvar Desbravador</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>

            <div className="border rounded-lg bg-card">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Nome</TableHead>
                            <TableHead>Data Nasc.</TableHead>
                            <TableHead>Classes/Espec.</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Ações</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {members.map((member) => (
                            <TableRow key={member.id}>
                                <TableCell className="font-medium">
                                    <div className="flex items-center">
                                        <UserIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                        {member.name}
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex items-center text-muted-foreground">
                                        <Calendar className="mr-2 h-3.3 w-3.5" />
                                        {new Date(member.dateOfBirth).toLocaleDateString()}
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <div className="flex gap-2 flex-wrap">
                                        {member.progress.length > 0 ? (
                                            member.progress.map(p => {
                                                const spec = p.type === 'specialty' ? specialties.find(s => s.id === p.id) : null
                                                const cls = p.type === 'class' ? classes.find(c => c.id === p.id) : null
                                                const name = spec?.name || cls?.name || p.id

                                                return (
                                                    <Badge key={p.id} variant="secondary" className="text-[10px] flex items-center gap-1.5 px-1.5 h-6">
                                                        {spec && (
                                                            <img
                                                                src={getSpecialtyImage(spec.code)}
                                                                className="w-3 h-3 object-contain"
                                                                onError={(e) => {
                                                                    (e.target as HTMLImageElement).src = "https://mda.wiki.br/site/@imgs/ico_especialidade_dbv.svg"
                                                                }}
                                                            />
                                                        )}
                                                        <span className="max-w-[100px] truncate">{name}</span>
                                                    </Badge>
                                                )
                                            })
                                        ) : (
                                            <span className="text-xs text-muted-foreground">Nenhuma ativa</span>
                                        )}
                                    </div>
                                </TableCell>
                                <TableCell>
                                    <Badge variant="outline">Ativo</Badge>
                                </TableCell>
                                <TableCell className="text-right">
                                    <Link href={`/dashboard/club/members/${member.id}`}>
                                        <Button variant="ghost" size="sm">
                                            Ver Progresso
                                            <ArrowRight className="ml-2 h-4 w-4" />
                                        </Button>
                                    </Link>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
                {members.length === 0 && (
                    <div className="p-8 text-center text-muted-foreground">
                        Nenhum desbravador cadastrado nesta unidade.
                    </div>
                )}
            </div>
        </div>
    )
}

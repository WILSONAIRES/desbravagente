"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { storageService } from "@/services/storage-service"
import { Unit } from "@/types/clube"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Users, ArrowRight } from "lucide-react"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function ClubPage() {
    const [units, setUnits] = useState<Unit[]>([])
    const [newUnitName, setNewUnitName] = useState("")
    const [open, setOpen] = useState(false)
    const [clubName, setClubName] = useState("Meu Clube")

    useEffect(() => {
        loadUnits()
        setClubName(storageService.getClubName())
    }, [])

    const loadUnits = () => {
        setUnits(storageService.getUnits())
    }

    const handleAddUnit = () => {
        if (!newUnitName.trim()) return

        const newUnit: Unit = {
            id: crypto.randomUUID(),
            name: newUnitName,
        }

        storageService.saveUnit(newUnit)
        setNewUnitName("")
        setOpen(false)
        loadUnits()
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-primary">{clubName}</h1>
                    <p className="text-muted-foreground">
                        Gerencie as unidades e acompanhe o progresso dos desbravadores.
                    </p>
                </div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild>
                        <Button>
                            <Plus className="mr-2 h-4 w-4" />
                            Nova Unidade
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Adicionar Nova Unidade</DialogTitle>
                            <DialogDescription>
                                Digite o nome da unidade para começar a cadastrar desbravadores.
                            </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                                <Label htmlFor="name">Nome da Unidade</Label>
                                <Input
                                    id="name"
                                    placeholder="Ex: Águia, Sentinelas..."
                                    value={newUnitName}
                                    onChange={(e) => setNewUnitName(e.target.value)}
                                />
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
                            <Button onClick={handleAddUnit}>Salvar Unidade</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {units.map((unit) => {
                    const memberCount = storageService.getMembers(unit.id).length
                    return (
                        <Link key={unit.id} href={`/dashboard/club/units/${unit.id}`}>
                            <Card className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-primary">
                                <CardHeader className="pb-2">
                                    <CardTitle className="flex items-center justify-between">
                                        {unit.name}
                                        <ArrowRight className="h-4 w-4 text-muted-foreground" />
                                    </CardTitle>
                                    <CardDescription>Unidade do Clube</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="flex items-center text-sm text-muted-foreground">
                                        <Users className="mr-2 h-4 w-4" />
                                        {memberCount} {memberCount === 1 ? 'Membro' : 'Membros'}
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>
                    )
                })}

                {units.length === 0 && (
                    <Card className="col-span-full border-dashed p-12 flex flex-col items-center justify-center text-center">
                        <Users className="h-12 w-12 text-muted-foreground mb-4 opacity-20" />
                        <h3 className="text-lg font-medium">Nenhuma unidade cadastrada</h3>
                        <p className="text-muted-foreground mb-4">
                            Comece criando sua primeira unidade para gerenciar seu clube.
                        </p>
                        <Button variant="outline" onClick={() => setOpen(true)}>
                            <Plus className="mr-2 h-4 w-4" />
                            Nova Unidade
                        </Button>
                    </Card>
                )}
            </div>
        </div>
    )
}

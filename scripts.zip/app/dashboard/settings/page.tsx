"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Eye, EyeOff, Save } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SettingsPage() {
    const [apiKey, setApiKey] = useState("")
    const [provider, setProvider] = useState("openai")
    const [modelName, setModelName] = useState("gpt-4o-mini")
    const [showKey, setShowKey] = useState(false)
    const [status, setStatus] = useState<"idle" | "saved">("idle")

    useEffect(() => {
        const storedKey = localStorage.getItem("ai_api_key")
        if (storedKey) setApiKey(storedKey)

        const storedProvider = localStorage.getItem("ai_provider")
        if (storedProvider) setProvider(storedProvider)

        const storedModel = localStorage.getItem("ai_model")
        if (storedModel) setModelName(storedModel)
    }, [])

    const handleProviderChange = (value: string) => {
        setProvider(value)
        // Set default model for provider
        if (value === "groq") {
            setModelName("llama-3.3-70b-versatile")
        } else if (value === "openai") {
            setModelName("gpt-4o-mini")
        } else {
            setModelName("gemini-2.0-flash")
        }
    }

    const handleSave = () => {
        if (apiKey.trim()) {
            localStorage.setItem("ai_api_key", apiKey.trim())
        } else {
            localStorage.removeItem("ai_api_key")
        }

        localStorage.setItem("ai_provider", provider)
        localStorage.setItem("ai_model", modelName.trim() || (provider === "openai" ? "gpt-4o-mini" : "gemini-2.0-flash"))

        setStatus("saved")
        setTimeout(() => setStatus("idle"), 2000)
    }

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>

            <Card>
                <CardHeader>
                    <CardTitle>Inteligência Artificial</CardTitle>
                    <CardDescription>
                        Configure o provedor e a chave de API para geração de conteúdo.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid gap-2">
                        <Label htmlFor="provider">Provedor de IA</Label>
                        <Select value={provider} onValueChange={handleProviderChange}>
                            <SelectTrigger>
                                <SelectValue placeholder="Selecione o provedor" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="groq">Groq (Gratuito - LLama/Mixtral)</SelectItem>
                                <SelectItem value="openai">OpenAI (ChatGPT)</SelectItem>
                                <SelectItem value="gemini">Google Gemini</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="grid gap-2">
                        <Label htmlFor="api-key">
                            {provider === "openai" ? "OpenAI API Key" : "Google Gemini API Key"}
                        </Label>
                        <div className="relative">
                            <Input
                                id="api-key"
                                type={showKey ? "text" : "password"}
                                placeholder={provider === "openai" ? "sk-..." : "AIza..."}
                                value={apiKey}
                                onChange={(e) => setApiKey(e.target.value)}
                                className="pr-10"
                            />
                            <Button
                                variant="ghost"
                                size="icon"
                                className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                                onClick={() => setShowKey(!showKey)}
                            >
                                {showKey ? (
                                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                                ) : (
                                    <Eye className="h-4 w-4 text-muted-foreground" />
                                )}
                            </Button>
                        </div>
                    </div>

                    <div className="grid gap-2">
                        <Label htmlFor="model-name">Modelo</Label>
                        <Input
                            id="model-name"
                            placeholder={
                                provider === "groq" ? "llama-3.3-70b-versatile" :
                                    provider === "openai" ? "gpt-4o-mini, gpt-4o" : "gemini-2.0-flash"
                            }
                            value={modelName}
                            onChange={(e) => setModelName(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">
                            {provider === "groq"
                                ? "Modelos gratuitos: llama-3.3-70b-versatile, mixtral-8x7b-32768, gemma2-9b-it"
                                : provider === "openai"
                                    ? "Modelos: gpt-4o-mini (barato), gpt-4o (melhor)"
                                    : "Modelos: gemini-2.0-flash, gemini-1.5-flash"
                            }
                        </p>
                    </div>

                    <Button onClick={handleSave} className="w-full sm:w-auto">
                        <Save className="mr-2 h-4 w-4" />
                        {status === "saved" ? "Salvo!" : "Salvar Configurações"}
                    </Button>
                </CardContent>
            </Card>
        </div>
    )
}
